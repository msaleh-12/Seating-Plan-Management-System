package application;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class controller {

    @FXML
    private Button studentsButton;

    @FXML
    private Button roomsButton;

    @FXML
    private Button invigilatorsButton;

    @FXML
    private Button examSchedulesButton;

    @FXML
    private Button searchStudentButton;

    @FXML
    private Button generateSeatingPlanButton;

    @FXML
    private Button assignInvigilatorButton;

    @FXML
    private Button logoutButton;

    @FXML
    public void initialize() {
        // Initialize any data or setup event handlers if necessary
    }

    @FXML
    private void handleStudentsButtonAction() {
        showAlert("Students Management", "Manage Students button clicked.");
    }

    @FXML
    private void handleRoomsButtonAction() {
        showAlert("Rooms Management", "Manage Rooms button clicked.");
    }

    @FXML
    private void handleInvigilatorsButtonAction() {
        showAlert("Invigilators Management", "Manage Invigilators button clicked.");
    }

    @FXML
    private void handleExamSchedulesButtonAction() {
        showAlert("Exam Schedules Management", "Manage Exam Schedules button clicked.");
    }

    @FXML
    private void handleSearchStudentButtonAction() {
        showAlert("Search Student", "Search Student button clicked.");
    }

    @FXML
    private void handleGenerateSeatingPlanButtonAction() {
        showAlert("Generate Seating Plan", "Generate Seating Plan button clicked.");
    }

    @FXML
    private void handleAssignInvigilatorButtonAction() {
        showAlert("Assign Invigilator", "Assign Invigilator button clicked.");
    }

    @FXML
    private void handleLogoutButtonAction() {
        showAlert("Logout", "Logout button clicked.");
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
